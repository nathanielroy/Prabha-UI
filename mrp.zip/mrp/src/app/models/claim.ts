export class Claim {
    claimId: number=0;
	memberId: string='';
	fName: string='';
    lName: string='';
	dob: Date;
	doa:Date;
	dod: Date;
	providerName:string;
	billAmt: number;
}