export class Dependent {
    memberId:string;
    dname: string;
	ddob: string; 
}