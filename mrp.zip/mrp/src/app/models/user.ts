export class User {
    fName: string;
    lName: string;
    dob: Date;
    username: string;
    password: string;
    token?: string;
  }